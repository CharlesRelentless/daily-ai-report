"""
AI 前沿捕手 Agent — 推送模块
QQ邮箱 SMTP + Notion API 双通道推送。
"""
import smtplib
import traceback
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime
from config import cfg


# ═══════════════════════════════════════════════════════════════
# QQ邮箱推送
# ═══════════════════════════════════════════════════════════════

def send_via_qqmail(report_md: str, date_str: str = None) -> bool:
    """通过 SMTP 发送日报（支持 QQ邮箱 / Gmail / 任意 SMTP）。"""
    if not cfg.ENABLE_EMAIL:
        print("[邮件] 未配置，跳过推送")
        return False

    date_str = date_str or datetime.now().strftime("%Y-%m-%d")

    try:
        msg = MIMEMultipart("alternative")
        msg["Subject"] = f"【AI 前沿日报 | {date_str}】"
        msg["From"] = cfg.EMAIL_SENDER
        msg["To"] = cfg.EMAIL_RECEIVER

        text_part = MIMEText(report_md, "plain", "utf-8")
        html_report = _md_to_html(report_md)
        html_part = MIMEText(html_report, "html", "utf-8")
        msg.attach(text_part)
        msg.attach(html_part)

        server = smtplib.SMTP(cfg.EMAIL_SMTP_HOST, cfg.EMAIL_SMTP_PORT, timeout=15)
        server.starttls()
        server.login(cfg.EMAIL_SENDER, cfg.EMAIL_AUTH_CODE)
        server.sendmail(cfg.EMAIL_SENDER, cfg.EMAIL_RECEIVER, msg.as_string())
        server.quit()
        print(f"[邮件] 日报已发送至 {cfg.EMAIL_RECEIVER} (via {cfg.EMAIL_SMTP_HOST})")
        return True
    except Exception as e:
        print(f"[邮件] 发送失败: {e}")
        traceback.print_exc()
        return False


def _md_to_html(md: str) -> str:
    """将简单 Markdown 转为 HTML 邮件格式。"""
    import re

    html = md
    # 标题
    html = html.replace("# 【AI 前沿日报", '<h2 style="color:#1a73e8;">【AI 前沿日报')
    html = html.replace("# ", "<h3>")
    # 二级标题
    html = html.replace("## ", '<h3 style="color:#333;border-bottom:1px solid #eee;padding-bottom:4px;">')
    # 粗体
    html = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", html)
    # 链接
    html = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", r'<a href="\2" style="color:#1a73e8;">\1</a>', html)
    # 引用
    html = html.replace("> *", '<p style="color:#888;font-size:13px;"><em>')
    # 列表
    html = html.replace("- ", '<li style="margin:6px 0;">')
    # 换行
    html = html.replace("\n\n", "<br><br>")
    html = html.replace("\n", "<br>")

    return f"""<html><body style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;max-width:680px;margin:0 auto;padding:20px;line-height:1.7;color:#333;">
{html}
</body></html>"""


# ═══════════════════════════════════════════════════════════════
# Notion 推送
# ═══════════════════════════════════════════════════════════════

def send_via_notion(report_md: str, date_str: str = None) -> bool:
    """通过 Notion API 将日报写入指定数据库。"""
    if not cfg.ENABLE_NOTION:
        print("[Notion] 未配置，跳过推送")
        return False

    date_str = date_str or datetime.now().strftime("%Y-%m-%d")

    payload = {
        "parent": {"database_id": cfg.NOTION_DATABASE_ID},
        "properties": {
            "Name": {
                "title": [{"text": {"content": f"AI 前沿日报 {date_str}"}}]
            },
            "Date": {
                "date": {"start": date_str}
            },
        },
        "children": _md_to_notion_blocks(report_md),
    }

    headers = {
        "Authorization": f"Bearer {cfg.NOTION_API_KEY}",
        "Content-Type": "application/json",
        "Notion-Version": "2022-06-28",
    }

    try:
        import requests
        r = requests.post(
            "https://api.notion.com/v1/pages",
            json=payload,
            headers=headers,
            timeout=20,
        )
        r.raise_for_status()
        page_url = r.json().get("url", "N/A")
        print(f"[Notion] 日报已创建: {page_url}")
        return True
    except Exception as e:
        print(f"[Notion] 推送失败: {e} | 响应: {getattr(e.response, 'text', 'N/A') if hasattr(e, 'response') else 'N/A'}")
        traceback.print_exc()
        return False


def _md_to_notion_blocks(md: str) -> list[dict]:
    """将 Markdown 切分为 Notion 块。简单分段处理。"""
    blocks = []
    lines = md.split("\n")
    for line in lines:
        line = line.strip()
        if not line:
            continue
        if line.startswith("# "):
            blocks.append({
                "object": "block",
                "type": "heading_1",
                "heading_1": {
                    "rich_text": [{"type": "text", "text": {"content": line[2:]}}]
                },
            })
        elif line.startswith("## "):
            blocks.append({
                "object": "block",
                "type": "heading_2",
                "heading_2": {
                    "rich_text": [{"type": "text", "text": {"content": line[3:]}}]
                },
            })
        elif line.startswith("- "):
            blocks.append({
                "object": "block",
                "type": "bulleted_list_item",
                "bulleted_list_item": {
                    "rich_text": [{"type": "text", "text": {"content": line[2:]}}]
                },
            })
        elif line.startswith("> "):
            blocks.append({
                "object": "block",
                "type": "quote",
                "quote": {
                    "rich_text": [{"type": "text", "text": {"content": line[2:]}}]
                },
            })
        elif line.startswith("![") or (line.startswith("[") and "](" in line):
            continue
        else:
            blocks.append({
                "object": "block",
                "type": "paragraph",
                "paragraph": {
                    "rich_text": [{"type": "text", "text": {"content": line}}]
                },
            })
    return blocks
