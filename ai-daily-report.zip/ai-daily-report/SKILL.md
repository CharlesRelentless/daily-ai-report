---
name: ai-daily-report
description: Route-based AI daily report. Two modes: (1) Quick mode — pull AI HOT curated daily/newsfeed API, generate single-file HTML dashboard with orange-red morning-briefing style; (2) Full mode — deploy a fully automated pipeline that scrapes ArXiv/GitHub/HN/RSS, uses LLM to filter/classify, then pushes via SMTP/Notion. Default to Quick mode unless user says "搭建"、"部署"、"自动化"、"定时"、"GitHub Actions" or "完整 pipeline".
agent_created: true
---

# AI Daily Report (AI 前沿捕手)

## 路由：两种模式

| 用户在说什么 | 走哪个模式 |
|---|---|
| **默认**："今天 AI 日报"、"AI 晨报"、"生成日报"、"看下日报"、"来个仪表盘" | **Quick Mode**（AI HOT API → HTML 仪表盘） |
| **明确部署需求**："搭建"、"部署"、"自动化"、"定时"、"GitHub Actions"、"完整 pipeline"、"推送邮件" | **Full Mode**（自建抓取 pipeline） |

> 核心原则：零门槛优先。Quick Mode 无需 API Key、无需 GitHub Actions、无需部署，一个 HTML 文件即拿即走。只有用户明确要自建 pipeline 时才走 Full Mode。

---

## Quick Mode：AI HOT API → HTML 晨报仪表盘

### 数据获取

唯一数据源：**AI HOT**（aihot.virxact.com），每日北京时间 08:00 自动生成日报，由编辑团队精选 + LLM 摘要，已按 5 个固定版块分类。

**API 端点速查：**

| 端点 | 用途 | 备注 |
|---|---|---|
| `GET /api/public/daily` | 最新日报（5 版块 + 主编点评） | 用户明确说"日报"时用 |
| `GET /api/public/items?mode=selected` | 精选条目（实时滚动，不限整日） | 用户说"今天 AI 圈"等宽问题时用 |
| `GET /api/public/items?mode=selected&category=<slug>` | 按分类筛选 | 用户说"最近 AI 论文"等 |
| `GET /api/public/daily/{YYYY-MM-DD}` | 指定日期日报 | 回退/历史查询 |

**分类 slug 映射：**

| 中文分类 | API slug |
|---|---|
| 模型发布/更新 | `ai-models` |
| 产品发布/更新 | `ai-products` |
| 行业动态 | `industry` |
| 论文研究 | `paper` |
| 技巧与观点 | `tip` |

**调用须知：**
- Base URL: `https://aihot.virxact.com`，匿名免鉴权
- **必须带浏览器 UA**，否则返回 403：`-H "User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"`
- 今日日报（`/api/public/daily`）若返回 404（"No daily report available yet"），说明当日 08:00 前尚未生成——自动回退到最近一期：先拉 `/api/public/dailies?take=3`，取最近可用日期再拉对应日报
- 每日只请求一次（内容不变），不要高频轮询

### 日报数据结构

```json
{
  "date": "2026-05-22",
  "generatedAt": "2026-05-22T00:00:00.182Z",
  "windowStart": "2026-05-21T00:00:00.000Z",
  "windowEnd": "2026-05-22T00:00:00.000Z",
  "lead": { "title": "主编点评标题", "leadParagraph": "导语..." } | null,
  "sections": [
    {
      "label": "模型发布/更新",
      "items": [
        { "title": "...", "summary": "...", "sourceUrl": "https://...", "sourceName": "..." }
      ]
    }
  ],
  "flashes": [
    { "title": "...", "sourceName": "...", "sourceUrl": "...", "publishedAt": "..." }
  ]
}
```

- `sections[].label` 固定 5 个，但某些版块可能无条目（如当日期刊论文为空）
- 每日 items 的 `publishedAt` 仅 flashes 有；正文卡片通过 `generatedAt` 推断相对时间

### HTML 仪表盘生成规范

生成**纯 HTML/CSS/JS 单文件**，所有样式与脚本内联，**禁止外部资源**。

#### 设计系统

```
CSS 变量（橙红渐变晨报风）：
  --gradient-start: #ff5e3a
  --gradient-mid:   #ff7b47
  --gradient-end:   #ff6b35
  --hero-bg-start:  #1a0a00
  --hero-bg-end:    #2d1200
  --card-bg:        #ffffff
  --card-border:    #f0e6e0
  --accent:         #e8552d
  --font-stack:     -apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Microsoft YaHei"...

分类色标：
  模型: #e04030  产品: #f58220  行业: #2d8cf0  论文: #7b4fbf  观点: #19be6b
```

#### 页面结构

1. **Hero 区域**
   - 深色渐变背景 + 径向光晕
   - 显示：日期（格式 "YYYY 年 M 月 D 日 · 星期X"）、总条数大数字、五个版块统计 pills（带分类色点）
   - 如在 `lead` 非 null，可在 Hero 或正文前显示主编点评

2. **锚点导航栏**
   - `position: sticky; top: 0`
   - 5 个版块链接 + 条数角标，点击平滑滚动
   - 滚动时高亮当前可见版块

3. **正文五个版块**
   - 每个版块：图标 + 中文标题 + 条数统计
   - 条目为 0 时显示空状态提示（如"本期暂无论文研究资讯"）

4. **卡片组件**
   - 响应式网格：`grid-template-columns: repeat(auto-fill, minmax(320px, 1fr)); gap: 16px`
   - 每张卡片包含：
     - **全局序号**（1 到 N，贯穿全文不重置）：橙色渐变圆标，`position: absolute` 悬于卡片左上角
     - **标题**：15px 粗体
     - **来源 chip**：圆角 pill，浅橙底 + 深橙色文字
     - **中文摘要**：≤60 字，13px 次级色
     - **时间标签**：人话格式（"今天上午" / "昨天" / "今天凌晨"）
     - **原文跳转按钮**：`target="_blank" rel="noopener noreferrer"`

5. **文末标注**
   - 总条数 + 数据源链接 `aihot.virxact.com`，12px 次级色

#### 交互要求

- **滚动渐入动画**：使用 `IntersectionObserver`，卡片初始 `opacity: 0; transform: translateY(24px)`，进入视口后添加 `.visible` 类触发过渡
- **卡片 hover**：轻微上浮 + 阴影加深 + 边框变色

#### 时间格式转换规则

日报的 items 无 `publishedAt` 字段，通过 `generatedAt`（UTC）推算相对时间：

| 场景 | 展示 |
|---|---|
| 北京时间当天 00:00 ~ 12:00 | "今天上午" |
| 北京时间当天 00:00 ~ 06:00 | "今天凌晨" |
| 北京时间前一天 | "昨天" |
| 更早 | "X 天前" |

> 禁止直接展示 ISO 8601 字符串（如 `2026-05-22T00:00:00.182Z`）

#### 输出格式

- 文件命名：`ai-daily-YYYY-MM-DD.html`
- 使用 `preview_url` 工具在 IDE 中预览
- 使用 `deliver_attachments` 工具投递给用户

### Quick Mode 完整执行步骤

```
1. 用 curl 调 https://aihot.virxact.com/api/public/daily（带浏览器 UA）
2. 若返回 404 → 调 /api/public/dailies?take=3 取最近日期，再拉对应日报
3. 解析 sections，统计各版块条数 + 总数
4. 生成内联数据的 JS 数组（title / summary(≤60字) / sourceUrl / sourceName / 序号）
5. 按上述 HTML 规范生成单文件，写入当前工作区
6. preview_url → deliver_attachments
```

---

## Full Mode：GitHub Actions 自动化部署

### Overview

Zero-LLM pipeline: **AI HOT API → HTML Dashboard → Gmail SMTP**. Deployed via GitHub Actions, runs weekdays at 08:30 BJT (right after AI HOT publishes at 08:00). No API key required except Gmail app password.

### When to Use Full Mode

- "帮我搭建一个每日 AI 前沿日报"
- "Build an automated AI newsletter / daily report"
- "定时推送到邮箱"
- "自动生成 HTML 日报"

### Architecture

```
AI HOT API           HTML Generator        Push
┌──────────────┐    ┌──────────────┐    ┌──────────┐
│ /api/public/ │───▶│ Dashboard    │───▶│ Gmail    │
│ daily        │    │ + Email-safe │    │ SMTP     │
│ (5 sections) │    │ HTML         │    │ (587)    │
└──────────────┘    └──────────────┘    └──────────┘
```

### How to Use

#### Quick Start (New Project)

1. Copy `scripts/` files into a `daily_ai_report/` directory
2. Copy `assets/daily_report.yml` into `.github/workflows/`
3. Copy `assets/.env.example` to `daily_ai_report/.env`
4. Fill in Gmail credentials
5. `pip install -r daily_ai_report/requirements.txt`
6. `python daily_ai_report/main.py --dry-run` to test
7. Set GitHub Secrets (only 5 needed):
8. Push and trigger Actions

#### Script Roles

| Script | Role |
|--------|------|
| `scripts/main.py` | Entry: fetch → generate → push |
| `scripts/aihot.py` | AI HOT API client (single call + 404 fallback) |
| `scripts/htmlgen.py` | Dual HTML: full dashboard + email-safe version |
| `scripts/push.py` | Generic SMTP (Gmail/QQ/any) |
| `scripts/config.py` | Env-var config |

#### Configuration

Required GitHub Secrets (only 5):

| Secret | Example | Notes |
|--------|---------|-------|
| `EMAIL_SMTP_HOST` | `smtp.gmail.com` | Gmail recommended |
| `EMAIL_SMTP_PORT` | `587` | STARTTLS |
| `EMAIL_SENDER` | `you@gmail.com` | Sender address |
| `EMAIL_AUTH_CODE` | 16-char app password | myaccount.google.com/apppasswords |
| `EMAIL_RECEIVER` | `you@qq.com` | QQ邮箱 + 微信提醒 自己搞定 |

### Pitfalls & Solutions

#### 1. AI HOT API: must send browser User-Agent

No UA → 403. Always include: `Mozilla/5.0 ... Chrome/124.0.0.0 Safari/537.36`

#### 2. AI HOT daily not ready before 08:00 BJT

Returns 404 if called too early. Implement fallback: hit `/api/public/dailies?take=3`, grab latest date, retry.

#### 3. Gmail from GitHub Actions: 587 STARTTLS, not 465 SSL

```python
server = smtplib.SMTP("smtp.gmail.com", 587, timeout=15)
server.starttls()
```

#### 4. Email HTML must be email-safe

No `<style>` blocks, no external CSS/JS, no grid/flexbox. Use inline styles and `<table>` layouts.

#### 5. Git push from China: SSH > HTTPS

HTTPS to GitHub is frequently blocked. Use SSH deploy key.

#### 6. GitHub MCP limitations

Read-only. Cannot create repos, update files, trigger workflows, or read logs.

### Project Layout on Disk

```
daily_ai_report/
├── main.py            # Entry point
├── config.py          # Env-var config
├── aihot.py           # AI HOT API client
├── htmlgen.py         # HTML generator
├── push.py            # SMTP push
├── requirements.txt   # Only requests + python-dotenv
├── .env               # Secrets (gitignored)
└── reports/           # Generated HTML (gitignored)

.github/workflows/
└── daily_report.yml   # Cron: weekdays 08:30 BJT
```
