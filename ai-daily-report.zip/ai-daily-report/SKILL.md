---
name: ai-daily-report
description: Deploy a fully automated AI daily frontier report pipeline that collects data from ArXiv, GitHub Trending, Hacker News, RSS blogs, uses LLM to filter and classify into a multi-dimensional radar report, then pushes via generic SMTP email and Notion API. Triggered when the user asks to build an AI daily report, AI news digest, or automated research newsletter.
agent_created: true
---

# AI Daily Report (AI 前沿捕手 Agent)

## Overview

A turnkey pipeline that produces a personalized daily AI research digest.
Four data sources → LLM filtering & classification → Markdown report → email + Notion push.
Deployed via GitHub Actions, runs weekdays at 14:00 Beijing time.

## When to Use

- "帮我搭建一个每日 AI 前沿日报"
- "Build an automated AI newsletter"
- "Set up a daily research digest with email push"
- "Deploy a cron job that scrapes ArXiv + GitHub + HN and emails me"

## Architecture

```
Data Collection        LLM Pipeline           Push
┌──────────────┐     ┌──────────────┐     ┌──────────┐
│ ArXiv (×2)   │────▶│ Step 1:      │────▶│ QQ/Gmail │
│ GitHub Trend │     │ Filter +     │     │ SMTP     │
│ Hacker News  │     │ Classify     │     ├──────────┤
│ RSS Blogs    │     │ (6 dims)     │     │ Notion   │
└──────────────┘     │       ▼      │     │ API      │
                     │ Step 2:      │     └──────────┘
                     │ Gen Markdown │
                     └──────────────┘
```

Six classification dimensions:
1. 模型·产品速递 — new model releases & product updates
2. 前沿研究信号 — breakthrough papers / benchmark leaps
3. 开发利器·Agent 生态 — coding agents, frameworks, tooling
4. 范式·观点火花 — deep blogs, methodology shifts
5. 开源亮点·灵感案例 — creative high-star GitHub repos
6. 科研方向 — user's research keyword matches (e.g. landslide detection, remote sensing)

## How to Use

### Quick Start (New Project)

1. Read `scripts/requirements.txt` for dependencies
2. Read `scripts/config.py` for all configurable parameters
3. Copy `assets/.env.example` to `.env` and fill in credentials
4. Copy `scripts/` files into a `daily_ai_report/` directory
5. Copy `assets/daily_report.yml` into `.github/workflows/`
6. Run `python daily_ai_report/main.py --dry-run` to test locally
7. Set GitHub Secrets matching `.env.example` keys
8. Push to GitHub and trigger Actions manually

### Script Roles

| Script | Role |
|--------|------|
| `scripts/main.py` | Entry point: orchestrates collect → filter → generate → push |
| `scripts/fetchers.py` | Four data sources + research-specific ArXiv query |
| `scripts/pipeline.py` | Two-step LLM: classify (JSON) → render (Markdown) |
| `scripts/push.py` | Generic SMTP + Notion API dual-channel push |
| `scripts/config.py` | Env-var based config with sensible defaults |

### Configuration

Required GitHub Secrets for Actions:

| Secret | Example | Notes |
|--------|---------|-------|
| `OPENAI_API_KEY` | `sk-...` or DeepSeek key | Any OpenAI-compatible API |
| `OPENAI_BASE_URL` | `https://api.deepseek.com` | DeepSeek / API Sky / etc. |
| `OPENAI_MODEL` | `deepseek-chat` | Model name |
| `EMAIL_SMTP_HOST` | `smtp.gmail.com` | Gmail recommended for GH Actions |
| `EMAIL_SMTP_PORT` | `587` | STARTTLS |
| `EMAIL_SENDER` | `you@gmail.com` | Sender address |
| `EMAIL_AUTH_CODE` | 16-char app password | Gmail: myaccount.google.com/apppasswords |
| `EMAIL_RECEIVER` | `you@qq.com` | Where to receive the report |
| `NOTION_API_KEY` | `secret_...` | Optional, from notion.so/my-integrations |
| `NOTION_DATABASE_ID` | UUID | Optional, database with Name (Title) + Date fields |
| `RESEARCH_KEYWORDS` | `landslide detection,SAR,remote sensing` | Comma-separated |

## Pitfalls & Solutions

These were encountered in real deployment and MUST be followed:

### 1. GitHub Actions YAML: no `||` defaults for secrets

```yaml
# ❌ BROKEN — workflow won't appear in Actions tab
OPENAI_BASE_URL: ${{ secrets.OPENAI_BASE_URL || 'https://api.openai.com/v1' }}

# ✅ CORRECT
OPENAI_BASE_URL: ${{ secrets.OPENAI_BASE_URL }}
```

Handle all defaults in Python `config.py`, not in the workflow YAML.

### 2. ArXiv query URL must be URL-encoded

```python
# ❌ Spaces/colons/parens cause http.client.InvalidURL
url = f"http://export.arxiv.org/api/query?search_query={query}"

# ✅ URL-encode first
from urllib.parse import quote
encoded_query = quote(query, safe="")
url = f"http://export.arxiv.org/api/query?search_query={encoded_query}"
```

### 3. MIMEText/MIMEMultipart creation inside try block

```python
# ❌ If _md_to_html raises, entire script exits 1
html_report = _md_to_html(report_md)  # outside try
try:
    msg = MIMEMultipart(...)

# ✅ Everything inside try
try:
    msg = MIMEMultipart(...)
    html_report = _md_to_html(report_md)
```

### 4. SMTP port: use 587 STARTTLS, not 465 SSL

GitHub Actions runners often block port 465 (SSL). Port 587 (STARTTLS) works reliably with Gmail.

```python
server = smtplib.SMTP("smtp.gmail.com", 587, timeout=15)
server.starttls()
```

### 5. Git push from China: SSH > HTTPS

HTTPS to GitHub is frequently blocked. Generate an SSH deploy key:

```bash
ssh-keygen -t ed25519 -f ~/.ssh/id_ed25519_github -N ""
# Add public key to GitHub repo → Settings → Deploy Keys (with write access)
git remote set-url origin git@github.com:user/repo.git
GIT_SSH_COMMAND="ssh -i ~/.ssh/id_ed25519_github" git push
```

### 6. GitHub MCP limitations

The GitHub connector has **read-only** permissions by default. It cannot:
- Create repositories
- Update files
- Trigger workflow dispatches
- Read workflow run logs

If the user needs these operations, guide them to use the GitHub web UI or manual git commands.

## Customizing for Different Research Domains

To adapt this pipeline for a different research area:

1. Edit `RESEARCH_KEYWORDS` in `.env` / GitHub Secrets
2. Modify the six dimension labels in `scripts/pipeline.py` → `FILTER_SYSTEM_PROMPT`
3. Adjust the `REPORT_SYSTEM_PROMPT` format if a different report layout is needed
4. Change `RSS_FEEDS` in `scripts/config.py` for domain-specific blogs

## Project Layout on Disk

```
daily_ai_report/
├── main.py            # Entry point
├── config.py          # Env-var config
├── fetchers.py        # Data collection
├── pipeline.py        # LLM pipeline
├── push.py            # Email + Notion
├── requirements.txt   # Dependencies
├── .env               # Secrets (gitignored)
└── reports/           # Generated reports (gitignored)

.github/workflows/
└── daily_report.yml   # Cron: weekdays 14:00 BJT
```
